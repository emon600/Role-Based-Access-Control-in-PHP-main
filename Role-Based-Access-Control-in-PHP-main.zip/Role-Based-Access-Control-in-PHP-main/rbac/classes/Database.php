<?php

/**
 * Database
 */
class Database
{
	protected $con = null;
	public $last_insert_id = 0;
	public $affected_rows = 0;

	public function __construct()
	{
		try{

			$str = DB_DRIVER.':host='.DB_HOST.';dbname='.DB_NAME;
			$this->con = new PDO($str,DB_USER,DB_PASS);
		}catch (PDOException $e){
			die($e->getMessage());
		}
	}

	public function getAll($sql, $data = [])
	{
		return $this->query($sql,$data)->fetchAll(PDO::FETCH_OBJ);
	}

	public function getOne($sql, $data = [])
	{
		return $this->query($sql,$data)->fetch(PDO::FETCH_OBJ);
	}

	public function query(string $sql, array $data = []):mixed
	{
		$this->last_insert_id = 0;
		$this->affected = 0;

		$stm = $this->con->prepare($sql);
		$res = $stm->execute($data);
 
		$this->last_insert_id = $this->con->lastInsertId();
		$this->affected = $stm->rowCount();

		return $stm;

	}

	public function create_tables()
	{
		//users table
		$sql = "
			CREATE TABLE IF NOT EXISTS users (
				id int unsigned primary key auto_increment,
				username varchar(30) null,
				email varchar(100) null,
				password varchar(255) null,
				date_created datetime,

				key (email)
			)
		";

		$this->query($sql);

		//user roles table
		$sql = "
			CREATE TABLE IF NOT EXISTS user_roles (
				id int unsigned primary key auto_increment,
				role varchar(30) null,
				disabled tinyint(1) unsigned default 0,

				key (disabled)
			)
		";

		$this->query($sql);

		//user roles map table
		$sql = "
			CREATE TABLE IF NOT EXISTS user_roles_map (
				id int unsigned primary key auto_increment,
				user_id int unsigned default 0,
				role_id int unsigned default 0,
				disabled tinyint(1) unsigned default 0,

				key (user_id),
				key (role_id)
			)
		";

		$this->query($sql);

		//roles permissions map table
		$sql = "
			CREATE TABLE IF NOT EXISTS roles_permissions_map (
				id int unsigned primary key auto_increment,
				role_id int unsigned default 0,
				permission varchar(30) null,
				disabled tinyint(1) unsigned default 0,

				key (role_id),
				key (permission)
			)
		";

		$this->query($sql);

		//posts table
		$sql = "
			CREATE TABLE IF NOT EXISTS posts (
				id int unsigned primary key auto_increment,
				user_id int unsigned,
				title varchar(100) null,
				content text null,
				date_created datetime,

				key (user_id),
				key (title)
			)
		";

		$this->query($sql);
	}
}