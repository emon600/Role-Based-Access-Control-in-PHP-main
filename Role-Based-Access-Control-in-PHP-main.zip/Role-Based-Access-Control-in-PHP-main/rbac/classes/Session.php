<?php

/**
 * Session
 */
class Session
{
	
	public function __construct()
	{
		if(empty(session_id()))
			session_start();
	}

	public function set(string $key, mixed $value):void
	{
		$_SESSION[$key] = $value;
	}

	public function get(string $key):mixed
	{
		if(isset($_SESSION[$key]))
			return $_SESSION[$key];

		return null;
	}

	public function delete(string $key):void
	{
		if(!empty($_SESSION[$key]))
			unset($_SESSION[$key]);
	}

	
	
}