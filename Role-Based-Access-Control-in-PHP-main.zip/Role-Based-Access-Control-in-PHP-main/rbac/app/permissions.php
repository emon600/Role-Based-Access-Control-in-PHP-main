<?php

$ses = new Session;
$arr = [

	'add user',
	'edit user',
	'delete user',
	'view users',
	'add post',
	'edit post',
	'delete post',
	'view posts',
	'add role',
	'edit role',
	'delete role',
	'view roles',
	'view admin section',
	'edit permissions',

];

$ses->set('permissions',$arr);