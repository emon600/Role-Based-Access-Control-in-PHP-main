<?php

spl_autoload_register(function($classname){

	$file = '../classes/'.ucfirst($classname).'.php';
	if(file_exists($file))
		require $file;
});

require 'config.php';
require 'helpers.php';
require 'permissions.php';
