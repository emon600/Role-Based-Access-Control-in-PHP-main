<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'rbac_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_DRIVER', 'mysql');