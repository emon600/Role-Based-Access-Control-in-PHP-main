<?php

function user_can(string $permission):bool
{
	$ses = new Session;
	$db = new Database;
	$user_row = $ses->get('USER');

	if(empty($user_row))
		return false;

	$sql = "select permission from roles_permissions_map where disabled = 0 && role_id in (select role_id from user_roles_map where disabled = 0 && user_id = :user_id)";
	$check = $db->getAll($sql,[
		'user_id'=>$user_row->id,
	]);

	$my_permissions = [];

	if($check)
	{
		$my_permissions = array_column($check, 'permission');

	}

	return in_array($permission, $my_permissions);
	
}

function dd($data):void
{
	echo '<pre>';
	print_r($data);
	echo '</pre>';
}

function esc(string $str):string
{
	return htmlspecialchars($str);
}

function get_date(string $str):string
{
	return date('jS M, Y',strtotime($str));
}

function redirect(string $path):void 
{
	header("Location: ".$path);
	die();
}