<?php

	require '../app/load.php';

	$tab = $_GET['tab'] ?? 'posts';
	$mode = $_GET['mode'] ?? 'list';
	$id = $_GET['id'] ?? '0';

	$db = new Database;
	$ses = new Session;

	switch ($tab) {
		case 'users':
			require 'admin.users.controller.php';
			break;
		case 'posts':
			require 'admin.posts.controller.php';
			break;
		case 'roles':
			require 'admin.roles.controller.php';
			break;
		
		default:
			require 'admin.posts.controller.php';
			break;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

	<div class="col-8 mx-auto border rounded p-2">
		<h3 class="text-center p-2 bg-primary text-white">Admin Area</h3>
		
		<?php require 'header.php'?>

		<?php if(user_can('view admin section')):?>

			<ul class="nav nav-tabs justify-content-center">

				<?php if(user_can('view posts')):?>
				  <li class="nav-item">
				    <a class="nav-link <?=($tab=='posts') ? 'active':''?>" href="admin.php?tab=posts">Posts</a>
				  </li>
				<?php endif?>

			  	<?php if(user_can('view roles')):?>
				  <li class="nav-item">
				    <a class="nav-link <?=($tab=='roles') ? 'active':''?>" href="admin.php?tab=roles">Roles</a>
				  </li>
				<?php endif?>

			<?php if(user_can('view users')):?>
			  <li class="nav-item">
			    <a class="nav-link <?=($tab=='users') ? 'active':''?>" href="admin.php?tab=users">Users</a>
			  </li>
			<?php endif?>
	 
			</ul>

			<?php

				switch ($tab) {
					case 'users':
						require 'admin.users.php';
						break;
					case 'posts':
						require 'admin.posts.php';
						break;
					case 'roles':
						require 'admin.roles.php';
						break;
					
					default:
						require 'admin.posts.php';
						break;
				}
			?>
		<?php else:?>
			<div class="alert alert-danger text-center">Access Denied!</div>
		<?php endif?>
	</div>
</body>
</html>