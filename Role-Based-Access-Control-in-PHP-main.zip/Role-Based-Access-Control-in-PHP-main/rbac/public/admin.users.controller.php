<?php
	
	if($mode == 'add')
	{

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
			$arr = [
				'username'=>$_POST['username'],
				'email'=>$_POST['email'],
				'date_created'=>date("Y-m-d H:i:s"),
				'password'=>password_hash($_POST['password'], PASSWORD_DEFAULT),
			];

			$sql = "insert into users (username,email,password,date_created) values (:username,:email,:password,:date_created)";
			$db->query($sql,$arr);

			$user_id = $db->last_insert_id;

			//save user roles
			if(is_array($_POST['roles']))
			{

				foreach ($_POST['roles'] as $role_id) {
 
					$sql = "insert into user_roles_map (user_id, role_id, disabled) values (:user_id, :role_id, 0)";
					$db->query($sql,[
						'user_id'=>$user_id,
						'role_id'=>$role_id
					]);
 
				}
			}

			redirect('admin.php?tab=users');
		}

	}else	
	if($mode == 'edit')
	{

		$row = $db->getOne("select * from users where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'username'=>$_POST['username'],
				'email'=>$_POST['email'],
				'id'=>$row->id,
			];
			
			$sql = "update users set username = :username, email = :email where id = :id limit 1";
			if(!empty($_POST['password'])){
				$arr['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
				$sql = "update users set password = :password, username = :username, email = :email where id = :id limit 1";
			}

			$db->query($sql,$arr);

			//save user roles
			//disable all roles
			$sql = "update user_roles_map set disabled = 1 where user_id = :user_id";
			$db->query($sql,['user_id'=>$row->id]);

			if(is_array($_POST['roles']))
			{

				foreach ($_POST['roles'] as $role_id) {

					$check = $db->getOne('select * from user_roles_map where user_id = :user_id && role_id = :role_id limit 1',[
						'user_id'=>$row->id,
						'role_id'=>$role_id
					]);
					if(empty($check))
					{
						$sql = "insert into user_roles_map (user_id, role_id, disabled) values (:user_id, :role_id, 0)";
						$db->query($sql,[
							'user_id'=>$row->id,
							'role_id'=>$role_id
						]);

					}else{
						$sql = "update user_roles_map set disabled = 0 where id = :id limit 1";
						$db->query($sql,[
							'id'=>$check->id,
						]);
					}
				}
			}

			redirect('admin.php?tab=users');
		}
		
	}else	
	if($mode == 'delete')
	{

		$row = $db->getOne("select * from users where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'id'=>$id,
			];

			$sql = "delete from users where id = :id limit 1";
			$db->query($sql,$arr);

			redirect('admin.php?tab=users');
		}
		
		
	}else{


	}
