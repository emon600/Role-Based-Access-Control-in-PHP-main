<?php
	
	$all_perms = $ses->get('permissions');

?>

<?php if($mode == 'add' && user_can('add post')):?>

	<form method="post" class="">
		<h4 class="my-2">Add Record</h4>

		<div class="row">
			<div class="col-md-12">
				<div class="input-group mb-3">
				  <span class="input-group-text" id="basic-addon1">Post Title:</span>
				  <input type="text" class="form-control" placeholder="Post Title" name="title">
				</div>
			</div>

			<div class="col-md-12 mb-3">
				<textarea name="content" class="form-control" rows="6" placeholder="Post content here"></textarea>
			</div>

		</div>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=posts">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<button class="btn btn-primary">Save</button>
		</div>
	</form>

<?php elseif($mode == 'edit' && user_can('edit post')):?>

	<?php

		$row = $db->getOne("select * from posts where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Edit Record</h4>

		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-12">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Post Title:</span>
					  <input value="<?=$row->title?>" type="text" class="form-control" placeholder="Post Title" name="title">
					</div>
				</div>

				<div class="col-md-12 mb-3">
					<textarea name="content" class="form-control" rows="6" placeholder="Post content here"><?=$row->content?></textarea>
				</div>

			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=posts">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-primary">Save</button>
			<?php endif?>
		</div>
	</form>

<?php elseif($mode == 'delete' && user_can('delete post')):?>

	
	<?php

		$row = $db->getOne("select * from posts where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Delete Record</h4>
		<div class="alert alert-danger text-center my-2">Are you sure you want to delete this record?!</div>
		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-12 mb-3">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Title:</span>
					  <div class="form-control" ><?=esc($row->title)?></div>
					</div>
				</div>

 				<div class="col-md-12 mb-3">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Content:</span>
					  <div class="form-control" ><?=esc($row->content)?></div>
					</div>
				</div>
				
 

			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=posts">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-danger">Delete</button>
			<?php endif?>
		</div>
	</form>

<?php else:?>

	<?php
		$rows = $db->getAll("select *,(select username from users where id = posts.user_id) as username from posts order by id desc");

	?>
	<h4 class="my-2">Posts List</h4>

	<?php if(user_can('view posts')):?>
	<table class="table table-bordered table-striped">
		
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>Owner</th>
			<th>Date</th>
			<th>
				<a href="admin.php?tab=posts&mode=add">
					<button class="btn btn-sm btn-primary">Add New</button>
				</a>
			</th>
		</tr>

		<?php if(!empty($rows)):?>
			<?php foreach($rows as $row):?>
				<tr>
					<td><?=$row->id?></td>
					<td><?=esc($row->title)?></td>
					<td>
						<?=esc($row->username)?>
					</td>
					<td><?=get_date($row->date_created)?></td>
 
					<td>
						<a class="text-warning" href="admin.php?tab=posts&mode=edit&id=<?=$row->id?>">
							Edit
						</a>
						.
						<a class="text-danger" href="admin.php?tab=posts&mode=delete&id=<?=$row->id?>">
							Delete
						</a>
 
					</td>
				</tr>
			<?php endforeach?>
		<?php else:?>
			<tr>
				<td colspan="5" class="text-center">No records found</td>
			</tr>
		<?php endif?>
		
	</table>
	<?php else:?>
		<div class="alert alert-danger text-center">Access Denied!</div>
	<?php endif?>
<?php endif?>