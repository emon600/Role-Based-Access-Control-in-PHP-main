<?php
	
	if($mode == 'add' && user_can('add role'))
	{

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
			$arr = [
				'role'=>$_POST['role'],
				'disabled'=>$_POST['disabled'],
			];

			$sql = "insert into user_roles (role,disabled) values (:role,:disabled)";
			$db->query($sql,$arr);

			redirect('admin.php?tab=roles');
		}

	}else	
	if($mode == 'edit' && user_can('edit role'))
	{

		$row = $db->getOne("select * from user_roles where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'role'=>$_POST['role'],
				'disabled'=>$_POST['disabled'],
				'id'=>$id,
			];

			$sql = "update user_roles set role = :role, disabled = :disabled where id = :id limit 1";
			$db->query($sql,$arr);

			redirect('admin.php?tab=roles');
		}
		
	}else	
	if($mode == 'delete' && user_can('delete role'))
	{

		$row = $db->getOne("select * from user_roles where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'id'=>$id,
			];

			$sql = "delete from user_roles where id = :id limit 1";
			$db->query($sql,$arr);

			redirect('admin.php?tab=roles');
		}
		
		
	}else{

		if($_SERVER['REQUEST_METHOD'] == 'POST' && user_can('edit permissions'))
		{
			//disable all permissions
			$sql = "update roles_permissions_map set disabled = 1 where id != 1";
			$db->query($sql);

			foreach ($_POST as $key => $arr) {
				
				if(is_array($arr))
				{
					foreach ($arr as $permission) {

						$row = $db->getOne('select * from roles_permissions_map where role_id = :role_id && permission = :permission limit 1',[
							'role_id'=>$key,
							'permission'=>$permission
						]);
						if(empty($row))
						{
							$sql = "insert into roles_permissions_map (role_id, permission, disabled) values (:role_id, :permission, 0)";
							$db->query($sql,[
								'role_id'=>$key,
								'permission'=>$permission
							]);

						}else{
							$sql = "update roles_permissions_map set disabled = 0 where id = :id limit 1";
							$db->query($sql,[
								'id'=>$row->id,
							]);
						}
					}
				}
			}
			redirect('admin.php?tab=roles');
		}
	}
