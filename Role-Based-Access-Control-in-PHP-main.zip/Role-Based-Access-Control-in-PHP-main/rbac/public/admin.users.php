<?php
	
	$all_perms = $ses->get('permissions');

?>

<?php if($mode == 'add'):?>

	<form method="post" class="">
		<h4 class="my-2">Add Record</h4>

		<div class="row">
			<div class="col-md-6">
				<div class="input-group mb-3">
				  <span class="input-group-text" id="basic-addon1">Username:</span>
				  <input type="text" class="form-control" placeholder="Username" name="username">
				</div>
			</div>
			<div class="col-md-6">
				<div class="input-group mb-3">
				  <span class="input-group-text" id="basic-addon1">Email:</span>
				  <input type="email" class="form-control" placeholder="Email" name="email">
				</div>
			</div>
			
			<div class="col-md-12 mb-3">
				<div>Select User Roles:</div>
				<?php

					$roles = $db->getAll('select * from user_roles order by role asc');
 
				?>
				<div class="row">
					<?php if(!empty($roles)):$num=0?>
						<?php foreach($roles as $role):$num++?>
							<div class="col-md-6">
							<div class=" form-check form-switch">
							  <input value="<?=esc($role->id)?>" name="roles[]" class="form-check-input" type="checkbox" role="switch" id="check<?=$num?>">
							  <label class="form-check-label" for="check<?=$num?>"><?=esc($role->role)?></label>
							</div>
							</div>
						<?php endforeach?>
					<?php else:?>
						<div class="text-center">No permissions found</div>
					<?php endif?>
				</div>
			</div>

			<div class="col-md-12">
				<div class="input-group mb-3">
				  <span class="input-group-text" id="basic-addon1">Password:</span>
				  <input type="password" class="form-control" placeholder="Password" name="password">
				</div>
			</div>
 
		</div>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=users">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<button class="btn btn-primary">Save</button>
		</div>
	</form>

<?php elseif($mode == 'edit'):?>

	<?php

		$row = $db->getOne("select * from users where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Edit Record</h4>

		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-6">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Username:</span>
					  <input value="<?=esc($row->username)?>" type="text" class="form-control" placeholder="Username" name="username">
					</div>
				</div>
				<div class="col-md-6">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Email:</span>
					  <input value="<?=esc($row->email)?>" type="email" class="form-control" placeholder="Email" name="email">
					</div>
				</div>

				<div class="col-md-12 mb-3">
					<?php

						$selected_roles = [];
						$roles = $db->getAll('select * from user_roles order by role asc');
						$check = $db->getAll('select role_id from user_roles_map where user_id = :id && disabled = 0',['id'=>$row->id]);
						if($check)
							$selected_roles = array_column($check, 'role_id');
					?>
					<div class="row">
						<?php if(!empty($roles)):$num=0?>
							<?php foreach($roles as $role):$num++?>
								<div class="col-md-6">
								<div class=" form-check form-switch">
								  <input <?=in_array($role->id, $selected_roles) ? 'checked':''?> value="<?=esc($role->id)?>" name="roles[]" class="form-check-input" type="checkbox" role="switch" id="check<?=$num?>">
								  <label class="form-check-label" for="check<?=$num?>"><?=esc($role->role)?></label>
								</div>
								</div>
							<?php endforeach?>
						<?php else:?>
							<div class="text-center">No permissions found</div>
						<?php endif?>
					</div>
				</div>

				<div class="col-md-12">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Password:</span>
					  <input value="" type="password" class="form-control" placeholder="Password (leave empty to keep old one)" name="password">
					</div>
				</div>
	 
			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=users">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-primary">Save</button>
			<?php endif?>
		</div>
	</form>

<?php elseif($mode == 'delete'):?>

	
	<?php

		$row = $db->getOne("select * from users where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Delete Record</h4>
		<div class="alert alert-danger text-center my-2">Are you sure you want to delete this record?!</div>
		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-8">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Name:</span>
					  <div class="form-control" ><?=esc($row->username)?></div>
					</div>
				</div>
 				<div class="col-md-8">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Email:</span>
					  <div class="form-control" ><?=esc($row->email)?></div>
					</div>
				</div>
 				
			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=users">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-danger">Delete</button>
			<?php endif?>
		</div>
	</form>

<?php else:?>

	<?php
		$rows = $db->getAll('select * from users order by id desc');

	?>
	<h4 class="my-2">Users List</h4>
	<table class="table table-bordered table-striped">
		
		<tr>
			<th>ID</th>
			<th>username</th>
			<th>Email</th>
			<th>Roles</th>
			<th>Date</th>
			<th>
				<a href="admin.php?tab=users&mode=add">
					<button class="btn btn-sm btn-primary">Add New</button>
				</a>
			</th>
		</tr>

		<?php if(!empty($rows)):?>
			<?php foreach($rows as $row):?>
				<tr>
					<td><?=$row->id?></td>
					<td><?=esc($row->username)?></td>
					<td><?=esc($row->email)?></td>
					<td>
						<?php

							$roles = $db->getAll('select * from user_roles where id in (select role_id from user_roles_map where user_id = :user_id && disabled = 0)',['user_id'=>$row->id]);
						?>
						<div class="row">
							<?php if(!empty($roles)):?>
								<?php foreach($roles as $role):?>
									<div class="col-md-12">
										<?=esc($role->role)?>
									</div>
								<?php endforeach?>
							<?php endif?>
						</div>
					</td>
					<td><?=get_date($row->date_created)?></td>
 
					<td>
						<a class="text-warning" href="admin.php?tab=users&mode=edit&id=<?=$row->id?>">
							Edit
						</a>
						.
						<a class="text-danger" href="admin.php?tab=users&mode=delete&id=<?=$row->id?>">
							Delete
						</a>
 
					</td>
				</tr>
			<?php endforeach?>
		<?php else:?>
			<tr>
				<td colspan="5" class="text-center">No records found</td>
			</tr>
		<?php endif?>
		
	</table>

<?php endif?>