<?php

require '../app/load.php';

$ses = new Session;
$ses->delete('USER');

redirect('login.php');