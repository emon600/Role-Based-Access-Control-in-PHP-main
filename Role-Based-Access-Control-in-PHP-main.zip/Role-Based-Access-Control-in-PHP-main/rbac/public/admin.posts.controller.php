<?php
	
	if($mode == 'add' && user_can('add post'))
	{

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
			$arr = [
				'title'=>$_POST['title'],
				'content'=>$_POST['content'],
				'date_created'=>date("Y-m-d H:i:s"),
				'user_id'=>1,
			];

			$sql = "insert into posts (title,content,user_id,date_created) values (:title,:content,:user_id,:date_created)";
			$db->query($sql,$arr);

			redirect('admin.php?tab=posts');
		}

	}else	
	if($mode == 'edit' && user_can('edit post'))
	{

		$row = $db->getOne("select * from posts where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'title'=>$_POST['title'],
				'content'=>$_POST['content'],
				'id'=>$id,
			];

			$sql = "update posts set title = :title, content = :content where id = :id limit 1";
			$db->query($sql,$arr);

			redirect('admin.php?tab=posts');
		}
		
	}else	
	if($mode == 'delete' && user_can('delete post'))
	{

		$row = $db->getOne("select * from posts where id = :id limit 1",['id'=>$id]);

		if($_SERVER['REQUEST_METHOD'] == 'POST' && $row)
		{

			$arr = [
				'id'=>$id,
			];

			$sql = "delete from posts where id = :id limit 1";
			$db->query($sql,$arr);

			redirect('admin.php?tab=posts');
		}
		
		
	}else{


	}
