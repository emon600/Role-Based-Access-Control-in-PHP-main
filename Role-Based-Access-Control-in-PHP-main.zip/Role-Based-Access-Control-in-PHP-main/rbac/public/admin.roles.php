<?php
	
	$all_perms = $ses->get('permissions');

?>

<?php if($mode == 'add' && user_can('add role')):?>

	<form method="post" class="">
		<h4 class="my-2">Add Record</h4>

		<div class="row">
			<div class="col-md-8">
				<div class="input-group mb-3">
				  <span class="input-group-text" id="basic-addon1">Role:</span>
				  <input type="text" class="form-control" placeholder="Role Name" name="role">
				</div>
			</div>

			<div class="col-md-4">
				<select class="form-select" name="disabled">
				  <option value="0">Enabled</option>
				  <option value="1">Disabled</option>
				</select>
			</div>

		</div>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=roles">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<button class="btn btn-primary">Save</button>
		</div>
	</form>

<?php elseif($mode == 'edit' && user_can('edit role')):?>

	<?php

		$row = $db->getOne("select * from user_roles where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Edit Record</h4>

		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-8">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Role:</span>
					  <input value="<?=$row->role?>" type="text" class="form-control" placeholder="Role Name" name="role">
					</div>
				</div>

				<div class="col-md-4">
					<select class="form-select" name="disabled">
					  <option <?=($row->disabled == 0) ? 'selected':''?> value="0">Enabled</option>
					  <option <?=($row->disabled == 1) ? 'selected':''?> value="1">Disabled</option>
					</select>
				</div>

			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=roles">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-primary">Save</button>
			<?php endif?>
		</div>
	</form>

<?php elseif($mode == 'delete' && user_can('delete role')):?>

	
	<?php

		$row = $db->getOne("select * from user_roles where id = :id limit 1",['id'=>$id]);
	?>
	<form method="post" class="">
		<h4 class="my-2">Delete Record</h4>
		<div class="alert alert-danger text-center my-2">Are you sure you want to delete this record?!</div>
		<?php if(!empty($row)):?>
			<div class="row">
				<div class="col-md-8">
					<div class="input-group mb-3">
					  <span class="input-group-text" id="basic-addon1">Role:</span>
					  <div class="form-control" ><?=esc($row->role)?></div>
					</div>
				</div>

				<div class="col-md-4">
					<div>Active: <?=($row->disabled) ? 'No':'Yes'?></div>
				</div>

			</div>
		<?php else:?>
			<div class="alert alert-danger text-center">No record was found!</div>
		<?php endif?>

		<div class="d-flex justify-content-between">
			<a href="admin.php?tab=roles">
				<button type="button" class="btn btn-secondary">Back</button>
			</a>
			<?php if(!empty($row)):?>
				<button class="btn btn-danger">Delete</button>
			<?php endif?>
		</div>
	</form>

<?php else:?>


	<?php
		$rows = $db->getAll('select * from user_roles order by id desc');

	?>
	<h4 class="my-2">Roles List</h4>
	<form method="post">

		<?php if(user_can('view roles')):?>
		<table class="table table-bordered table-striped">
			
			<tr>
				<th>ID</th>
				<th>Role</th>
				<th>Active</th>
				<th class="d-flex justify-content-between">
					<div>Permissions</div>

					<?php if(user_can('edit permissions')):?>
						<button class="btn btn-sm btn-primary">Save Permissions</button>
					<?php endif?>
				</th>
				<th>
					<?php if(user_can('add role')):?>
					<a href="admin.php?tab=roles&mode=add">
						<button type="button" class="btn btn-sm btn-primary">Add New</button>
					</a>
					<?php endif?>
				</th>
			</tr>

			<?php if(!empty($rows)):?>
				<?php foreach($rows as $row):?>

					<?php
						$selected_permissions = [];
						$check = $db->getAll('select permission from roles_permissions_map where role_id = :role_id && disabled = 0',[
							'role_id'=>$row->id
						]);
						if($check){
							$selected_permissions = array_column($check, 'permission');
						}
					?>
					<tr>
						<td><?=$row->id?></td>
						<td><?=esc($row->role)?></td>
						<td><?=($row->disabled) ? 'No':'Yes'?></td>
						<td style="max-width: 200px;">
							<div class="row">
								<?php if(!empty($all_perms)):$num=0?>
									<?php foreach($all_perms as $perm):$num++?>
										<div class="col-md-6">
										<div class=" form-check form-switch">
										  <input <?=in_array($perm, $selected_permissions) ? 'checked':''?> value="<?=esc($perm)?>" name="<?=$row->id?>[]" class="form-check-input" type="checkbox" role="switch" id="check<?=$row->id?><?=$num?>">
										  <label class="form-check-label" for="check<?=$row->id?><?=$num?>"><?=esc($perm)?></label>
										</div>
										</div>
									<?php endforeach?>
								<?php else:?>
									<div class="text-center">No permissions found</div>
								<?php endif?>
							</div>
						</td>
						<td>
							<?php if(user_can('edit role')):?>
								<a class="text-warning" href="admin.php?tab=roles&mode=edit&id=<?=$row->id?>">
									Edit
								</a>
								.
							<?php endif?>
							<?php if(user_can('delete role')):?>
							<a class="text-danger" href="admin.php?tab=roles&mode=delete&id=<?=$row->id?>">
								Delete
							</a>
	 						<?php endif?>
						</td>
					</tr>
				<?php endforeach?>
			<?php else:?>
				<tr>
					<td colspan="5" class="text-center">No records found</td>
				</tr>
			<?php endif?>
			
		</table>

	<?php else:?>
		<div class="alert alert-danger text-center">Access Denied!</div>
	<?php endif?>

	</form>

<?php endif?>