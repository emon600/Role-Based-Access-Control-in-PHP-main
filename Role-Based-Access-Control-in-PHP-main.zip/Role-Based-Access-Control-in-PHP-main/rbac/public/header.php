<?php
	$ses = new Session;
	$username = $ses->get('USER')->username ?? 'Guest';
?>
<div>Hi, <?=esc($username)?></div>
<div class="p-2 shadow rounded m-2 text-center">
	<a href="index.php">Home</a> . 
	<a href="admin.php">Admin</a> . 
	<a href="login.php">Login</a> .
	<a href="logout.php">Logout</a> 
</div>
