<?php

	require '../app/load.php';

	$error = '';
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		$db = new Database;
		$row = $db->getOne('select * from users where email = :email limit 1',['email'=>$_POST['email']]);
		if($row)
		{
			if(password_verify($_POST['password'], $row->password))
			{
				$ses = new Session;
				$ses->set('USER',$row);

				redirect('admin.php');
			}

			$error = 'Wrong email or password';

		}

		$error = 'Wrong email or password';

	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

		<div class="col-8 mx-auto border rounded p-2">
			<h3 class="text-center p-2 bg-primary text-white">Login</h3>

			<?php require 'header.php'?>
		
			<form method="post" class="my-4 col-md-6 mx-auto shadow p-2">

				<?php if(!empty($error)):?>
					<div class="alert alert-danger text-center"><?=$error?></div>
				<?php endif?>

				<h4 class="text-center my-3">Login to Continue</h4>
				<div class="form-floating mb-3">
				  <input name="email" type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
				  <label for="floatingInput">Email</label>
				</div>
				<div class="form-floating mb-3">
				  <input name="password" type="password" class="form-control" id="floatingPassword" placeholder="Password">
				  <label for="floatingPassword">Password</label>
				</div>

				<button class="btn btn-lg btn-primary">Login</button>
			</form>
		</div>
</body>
</html>

