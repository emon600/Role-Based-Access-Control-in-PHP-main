<?php

require '../app/load.php';

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

		<div class="col-8 mx-auto border rounded p-2">
			<h3 class="text-center p-2 bg-primary text-white">Home Page</h3>

			<?php require 'header.php'?>
		
		</div>
</body>
</html>

